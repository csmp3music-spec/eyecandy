# sonic screwdriver eyecandy

A rebuilt Swift desktop app for psychedelic visuals and experimental music performance.

Current rebuilt features:

- 100 procedural psychedelic video presets.
- 140 procedural psychedelic video presets, including Minter and holographic families.
- Dropdown inspector navigation for presets, sequencer, synth, drums, keyboard, performance, and output.
- SwiftUI TimelineView/Canvas renderer with beat-reactive symmetry, tunnels, rings, demoscene scan lines, and modulation.
- Jeff Minter-inspired neon grid, orbiting light-synth, and arcade vortex overlays.
- Holographic scan-volume, chroma-depth, and interference overlays.
- 80s/90s demoscene overlays: Amiga copper bars, VGA plasma, rotozoomer, vector balls, star tunnel, sine scroller, chunky VGA, and Mega Demo mode.
- Advanced light-synth panel with XY macro pad, photon director, flash safety, prism splits, phosphor persistence, and Trip Max/Safe Cruise performance buttons.
- Light-synth modes: Hyper Prism, Lissajous Laser, Recursive Bloom, Acid Scope, Photon Storm, Neural Mandala, and Everything.
- Full performance controls: eight-slot scene deck, palette modes, blend/key styles, blackout, freeze frame, strobe gate, strobe safety, and MP4 parity.
- Beat-synced multitap delay FX with per-tap beat offset, level, feedback, and visual spread.
- Music-reactive visual multitap delay: delayed audio taps create matching delayed visual ghost rings and rays in live view and MP4 export.
- Expansive visual engine selector: Light Tunnel, Vector Field, Metaballs, Terrain Grid, Oscilloscope Ribbons, Fractal Lightning, Particle Nebula, Shape Constellation, Liquid Cells, and Engine Autopilot.
- Fractal Trees engine for branching organic light forms.
- Every preset change hard-cuts the screen and procedurally regenerates a new visual scene/profile instead of only recoloring the previous design.
- 64 named Jeff Minter-inspired signature presets with tuned Minter modes, palettes, engines, light-synth modes, demoscene layers, and holographic layers.
- Stereoscopic output modes: red/cyan anaglyph, side-by-side, top/bottom, line interlace, and depth ghost with stereo depth control.
- AVAudioEngine procedural synth output.
- 16-step bass, lead, kick, snare, hat, and clap pattern editing.
- Analog bass and lead voice controls.
- Drum preset library.
- 48-key live synth keyboard.
- Autopilot scene morphing and routable modulation slots.
- MP4 recording/export through AVAssetWriter.
- YouTube/Facebook/custom RTMP broadcast panel using `ffmpeg` to loop the latest MP4 recording to an RTMP/RTMPS ingest URL.

Run locally:

```sh
swift run
```

Smoke-test MP4 recording:

```sh
swift run eyecandy --record-smoke
```

Recordings are written to `recordings/`.

Broadcasting:

1. Record an MP4 from the Output panel.
2. Open the Broadcast panel.
3. Choose YouTube Live, Facebook Live, or Custom RTMP.
4. Paste the ingest URL and stream key from the service.
5. Start Broadcast.

The app keeps the stream key in memory only. Starting a broadcast sends the selected recording to the configured third-party RTMP service.
